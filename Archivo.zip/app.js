const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

const apiKey = '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';
const openaiEndpoint = 'https://api.openai.com/v1/engines/text-davinci-003/completions'; // Utiliza 'davinci' en lugar de 'text-davinci-003'

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/obtener_respuesta', async (req, res) => {
  const entradaUsuario = req.body.entrada_usuario;

  try {
    const respuestaModelo = await obtenerRespuestaOpenAI(entradaUsuario);
    res.send(respuestaModelo);
  } catch (error) {
    console.error('Error al obtener respuesta de OpenAI:', error.message);
    res.status(500).send('Error interno del servidor');
  }
});

async function obtenerRespuestaOpenAI(prompt) {
  try {
    const respuesta = await axios.post(
      openaiEndpoint,
      {
        prompt: prompt,
        max_tokens: 150 // Reducido para obtener respuestas más concisas
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        }
      }
    );

    console.log('Respuesta de OpenAI:', respuesta.data);
    
    // Verifica si hay una respuesta válida
    if (respuesta.data && respuesta.data.choices && respuesta.data.choices.length > 0) {
      return respuesta.data.choices[0].text.trim();
    } else {
      throw new Error('Respuesta de OpenAI no válida');
    }
  } catch (error) {
    console.error('Error al hacer la solicitud a OpenAI:', error.message);
    throw error;
  }
}

app.listen(port, () => {
  console.log(`La aplicación está escuchando en http://localhost:${port}`);
});
